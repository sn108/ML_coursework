"""
ML4ChemEng Coursework 1 Part 2.

Authors: Elton Lam, Zhongqi Zhuang, John Huang & Nicholas Gerard. Team Abyss.
"""

import numpy as np
import time

class Jordanla:
    def __init__(self, func, x_dim, bounds, iter_tot) -> None:
        self.func         = func                        # The black box function to be minimised
        self.x_dim        = x_dim                       # Number of dimensions of the function
        self.bounds       = bounds                      # Bounds for each dimension
        self.lb, self.ub  = bounds[:, 0], bounds[:, 1]  # Lower and upper bound
        self.iter_tot     = iter_tot                    # Maximum iterations to perform
        self.evals        = 0                           # Initialize number of func evaluation counter
        self.n            = self.x_dim + 1              # Size of polygon       
    
    def bound_values(self, Ks):
        """ Ensures values do not exceed bounds. """
        # Apply bounds to each value in array Ks
        for j in range(len(Ks)):
            Ks[j] = np.clip(Ks[j], self.lb[j], self.ub[j])
        return Ks
    
    def simc_tuning(self):
        """ SIMC tuning heuristics to obtain intitial Ks for algorithm. """
        # Transfer function parameters, assuming FOPTD
        lamb, Td                = 1, 0 
        Kp_Ca, tau_Ca           = -0.013, 1.25
        Kp_T, tau_T             = 1.41, 2.75
        # Parameters obtained from SIMC tuning rules
        Kc_Ca, Kc_Tr, Kc_Tc     = tau_Ca/(Kp_Ca*(lamb + Td)), tau_T/(Kp_T*(lamb + Td)), 300
        ti_Ca, ti_Tr            = min(tau_Ca, 4*(tau_Ca + Td)), min(tau_T, 4*(tau_T + Td))
        td_Ca, td_Tr            = (self.lb[2] + self.ub[2])/2, (self.lb[5] + self.ub[5])/2

        Ks0 = self.bound_values(np.array([Kc_Ca, ti_Ca, td_Ca, Kc_Tr, ti_Tr,td_Tr, Kc_Tc]))
        Ks0 = Ks0.reshape(self.x_dim,)
        return Ks0
    
    def initialize_polygon(self):
        """
        Create a polygon of size x_dim + 1 around the starting point. 

        Parameters:
            step_size (int): Size of step away from starting point, for each K.
        Returns:
            polygon: Numpy array of points denoting the vertices of the polygon.
        """
        step_size   = [0.2, 0.2, 0.2, -0.3, -0.3, -0.3, 0.1] * (self.ub - self.lb)
        
        polygon_ones   = np.ones((self.n, 1))
        Ks0            = self.simc_tuning()
        polygon        = polygon_ones * Ks0
    
        for i in range(1, self.n):
            polygon[i, i - 1] += step_size[i - 1]   # Step size in each dimension
                   
        for j in range(self.x_dim):
            polygon[j] = self.bound_values(polygon[j])
        return polygon

    def evaluate_polygon(self, polygon):
        """ Evaluate the black box function at each point of the polygon. """

        func_vals   = np.array([self.func(point) for point in polygon])
        self.evals  += self.n   # Add n to func evaluation counter
        return func_vals

    def update_polygon(self, polygon, func_vals):
        """ Based on certain criteria, update the polygon. """

        worst_xloc      = np.argmax(func_vals)
        # Determine the centroid of the polygon's points, without considering the worst point
        centroid        = np.mean(np.delete(polygon, worst_xloc, 0), axis=0)
        # Reflect the worst point across the centroid; reflection: coordinates of reflected worst point
        reflection      = centroid + (centroid - polygon[worst_xloc])
        # Ensure that reflected point does not exceed function bounds
        reflection      = self.bound_values(reflection)
        # Evaluate the black box function's value at the reflected point
        reflection_val  = self.func(reflection)
        self.evals      += 1  # Add 1 to func evaluation counter

        # If func value at reflection is better than worst func value in polygon:
        if reflection_val < func_vals[worst_xloc]:
            # Replace worst polygon point with reflected point
            polygon[worst_xloc]     = reflection
            func_vals[worst_xloc]   = reflection_val
        else:
            # If not, shrink the polygon by interval bisection
            polygon[worst_xloc] = (polygon[worst_xloc] + centroid) / 2        
        return polygon, func_vals

    def main(self):
        """ Excute functions in order, check time, and iterate. """
        
        start_time   = time.time()  # Start timer
        timeout      = start_time + 50   # Timeout 50 seconds from timer start
        polygon      = self.initialize_polygon()
        func_vals    = self.evaluate_polygon(polygon)
        
        # Iterate for the remaining number of allowed func evaluations
        for _ in range(self.iter_tot - self.n):
            polygon, func_vals = self.update_polygon(polygon, func_vals)
        
            # If time exceeds budget, exit loop
            if time.time() > timeout:
                break
            # Before func evaluations exceed budget, exit loop
            if self.evals > (self.iter_tot):
                break

        best_idx = np.argmin(func_vals)
        best_x   = polygon[best_idx]
        best_f   = func_vals[best_idx]
        return best_x, best_f

def algorithm_Abyss(black_box_function, x_dim, bounds, iter_tot):
    """ Run algorithm, show desired ouputs. """

    best_Y = None
    gametime        = Jordanla(black_box_function, x_dim, bounds, iter_tot)
    best_x, best_f  = gametime.main()
    team_names      = ['Nicholas Gerard', 'Elton Lam', 'Zhongqi Zhuang', 'John Huang']
    cids            = ['01842998', '01848308', '01879376', '01854059']
    return best_x, best_f, best_Y, team_names, cids

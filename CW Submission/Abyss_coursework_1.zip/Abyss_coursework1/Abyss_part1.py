"""
ML4ChemEng Coursework 1 Part 1.

Jordanla, an algorithm to challenge Scipy's (Kobe) Cobyla. Created in Autumn 2023.

Authors: Elton Lam, Zhongqi Zhuang, John Huang & Nicholas Gerard. Team Abyss.
"""

import numpy as np
import time

class Jordanla:
    def __init__(self, func, x_dim, bounds, iter_tot) -> None:
        self.func        = func              # The black box function to be minimised
        self.x_dim       = x_dim             # Number of dimensions of the function
        self.bounds      = bounds            # Bounds for each dimension
        self.iter_tot    = iter_tot          # Maximum iterations to perform
        self.n           = self.x_dim + 1    # Size of polygon
        self.iters       = 0                 # Initialize number of func evaluation counter

    def initialize_polygon(self, step_size=3):
        """
        Create a polygon of size x_dim + 1 near the chosen start point. 

        Parameters:
            step_size (int): Size of step away from starting point. Fixed at 3.
        Returns:
            polygon: Numpy array of points denoting the vertices of the polygon.
        """
        # Array to store polygon values
        polygon     = np.zeros((self.n, self.x_dim))
        # Chosen start point at the middle of bounds
        start_point = (self.bounds[:,0] + self.bounds[:,1]) / 2
        # Set chosen start point as polygon's first point
        polygon[0]  = start_point
        
        for i in range(1, self.n):
            polygon[i, i - 1] += step_size   # Step size in each dimension
        
        # Centre the polygon around the chosen starting point
        centroid_polygon = np.mean(polygon, axis=0)
        polygon_centred = polygon - centroid_polygon # Translation step
        return polygon_centred

    def evaluate_polygon(self, polygon):
        """ Evaluate the black box function at each point of the polygon. """

        func_vals   = np.array([self.func(point) for point in polygon])
        self.iters  += self.n   # Add n to func evaluation counter
        return func_vals

    def update_polygon(self, polygon, func_vals):
        """ Based on certain criteria, update the polygon. """
        # Lower and upper bound
        lb, ub         = self.bounds[:, 0], self.bounds[:, 1]
        worst_xloc     = np.argmax(func_vals)
        # Determine the centroid of the polygon's points, without considering the worst point
        centroid       = np.mean(np.delete(polygon, worst_xloc, 0), axis=0)
        # Reflect the worst point across the centroid; reflection: coordinates of reflected worst point
        reflection     = centroid + (centroid - polygon[worst_xloc])
        # Ensure that reflected point does not exceed function bounds
        for j in range(len(reflection)):
            reflection[j] = np.clip(reflection[j], lb[j], ub[j])
        # Evaluate the black box function's value at the reflected point
        reflection_val = self.func(reflection)
        self.iters     += 1  # Add 1 to func evaluation counter

        # If func value at reflection is better than worst func value in polygon:
        if reflection_val < func_vals[worst_xloc]:
            # Replace worst polygon point with reflected point
            polygon[worst_xloc]     = reflection
            func_vals[worst_xloc]   = reflection_val
        else:
            # If not, shrink the polygon by interval bisection
            polygon[worst_xloc]     = (polygon[worst_xloc] + centroid) / 2
        return polygon, func_vals

    def main(self):
        """ Excute functions in order, check time, and iterate. """
        
        start_time   = time.time()  # Start timer
        timeout      = start_time + 50   # Timeout 50 seconds from timer start
        polygon      = self.initialize_polygon()
        func_vals    = self.evaluate_polygon(polygon)
        
        # Iterate for the remaining number of allowed func evaluations
        for _ in range(self.iter_tot - self.n):
            polygon, func_vals = self.update_polygon(polygon, func_vals)
        
            # If time exceeds budget, exit loop
            if time.time() > timeout:
                break
            # If func evaluations exceed budget, exit loop
            if self.iters > self.iter_tot:
                break

        best_idx = np.argmin(func_vals)
        best_x   = polygon[best_idx]
        best_f   = func_vals[best_idx]
        return best_x, best_f

def algorithm_Abyss(black_box_function, x_dim, bounds, iter_tot):
    """ Run algorithm, show desired ouputs. """

    gametime        = Jordanla(black_box_function, x_dim, bounds, iter_tot)
    best_x, best_f  = gametime.main()
    team_names      = ['Nicholas Gerard', 'Elton Lam', 'Zhongqi Zhuang', 'John Huang']
    cids            = ['01842998', '01848308', '01879376', '01854059']
    return best_x, best_f, team_names, cids

"""
ML4ChemEng Coursework 2.

Authors: Elton Lam, Zhongqi Zhuang, John Huang & Nicholas Gerard. Team Abyss.
"""

import pandas as pd
import numpy as np
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import mean_absolute_error, accuracy_score

def fit_preprocess(data_path):
    """
    Return a single object representing the parameters used to preprocess the
    data.
    In this example, we return a dictionary with the mean and standard
    deviation for standardization.

    Parameters
    ----------
    data_path : str
        Path to the csv file containing the data.

    Returns
    -------
    preprocess_params : dict
        Dictionary containing the parameters used to preprocess the data.
    """
    # Load from file
    data = pd.read_csv(data_path)
    data = data.drop('label', axis = 1) # Drop label column
    # Obtain preprocess parameters
    X = data.to_numpy()
    mean = np.mean(X, axis=0)
    std  = np.std(X, axis=0)
    preprocess_params = {'mean': mean, 'std': std}
    return preprocess_params


def load_and_preprocess(data_path, preprocess_params):
    """
    This function loads and preprocesses data from a csv file
    In this example, we read the first feature as the variable of interest,
    then standardize the data.

    Parameters
    ----------
    data_path : str
        Path to the csv file containing the data.
    preprocess_params : dict
        Dictionary containing the parameters used to preprocess the data.

    Returns
    -------
    X : 2D numpy array
        Preprocessed data. Make sure X is of shape: (n_instances, n_features).
    y : 1D numpy array
        True normal/anomaly labels of the data.
    """
    X = pd.read_csv(data_path)
    y = X['label'].to_numpy()
    X = X.drop('label', axis = 1) # Drop label column

    mean = preprocess_params['mean']
    std = preprocess_params['std']
    X = (X - mean) / std
    return X, y


def fit_model(X):
    """
    Returns the fitted model. In this simple example, the anomaly detection
    model is the threshold that will flag anomalies, but it can be any object
    as long as the predict() function knows how to handle it when passed as an
    argument.

    Parameters
    ----------
    X : 2D numpy array.
        Already preprocessed data used to fit the model.

    Returns
    -------
    model : dict
        Contaiing threshold and Fitted model.
    """

    # Autoencoder architecture
    n_input = X.shape[1] # Shape of input and latent variable
    n_encoder0 = 32
    n_encoder1 = 16
    n_encoder2 = 8
    n_latent   = 2
    n_decoder1 = 8
    n_decoder2 = 16
    n_decoder3 = 32
    n_output = n_input

    hidden_layer_sizes = (n_input, n_encoder0, n_encoder1, n_encoder2,
                        n_latent,
                        n_decoder1, n_decoder2, n_decoder3, n_output)
    
    # Initialise model using MLP
    model_layers = MLPRegressor(
        hidden_layer_sizes=hidden_layer_sizes, 
        activation='tanh', 
        solver='adam', 
        batch_size='auto', 
        learning_rate_init=0.001,
        learning_rate='adaptive',
        max_iter=1000,
        random_state=None,
        tol=0.000000001,
        verbose=False,
        alpha=0.001
    )

    # Fit the model
    regr = model_layers.fit(X, X)
    decoder_out = regr.predict(X)
    train_loss = []
    for row in range(X.shape[0]):
        tl = mean_absolute_error(decoder_out[row], X.iloc[row,:])
        train_loss = np.append(train_loss, tl)

    threshold = train_loss.mean() + 1 * train_loss.std()
    model = {'threshold': threshold, 'regr': regr}
    return model
    

def predict(X, model):
    """
    Accepts a 2D numpy array and an anomaly detection model, and returns a 1D
    array of predictions.

    Parameters
    ----------
    X : 2D numpy array.
        Preprocessed data.
    model : object
        Anomaly detection model.

    Returns
    -------
    y_pred : 1D numpy array.
        Array of normal/anomaly predictions.
    """
    
    decoder_out = model['regr'].predict(X)
    train_loss = []
    for row in range(X.shape[0]):
        tl = mean_absolute_error(decoder_out[row], X.iloc[row,:])
        train_loss = np.append(train_loss, tl)
    
    limit = model['threshold']
    n = len(train_loss)
    y_pred = np.zeros((n,))
    for i in range(len(X)):
        if train_loss[i] > limit:
            y_pred[i] = 1
        else:
            y_pred[i] = 0
    return y_pred


def main():
    """
    Main function to test the code when running this script standalone. Not
    mandatory for the deliverable but useful for the grader to check the code
    workflow and for the student to check it works as expected.
    """
    train_path = 'https://raw.githubusercontent.com/iraola/ML4CE-AD/main/coursework/data/data_train.csv'
    test_path = 'https://raw.githubusercontent.com/iraola/ML4CE-AD/main/coursework/data/data_test.csv'
    
    # Set up preprocessing
    preprocess_params = fit_preprocess(train_path)

    # Load and preprocess data
    X_train, y_train = load_and_preprocess(train_path, preprocess_params)
    X_test, y_test = load_and_preprocess(test_path, preprocess_params)

    # Get the detection model
    model = fit_model(X_train)

    # Check performance on data
    # (just for us to see it works properly, the grader might use other data)
    y_pred_train = predict(X_train, model)
    print('Training accuracy: ', accuracy_score(y_train, y_pred_train))
    y_pred_test = predict(X_test, model)
    print('Test accuracy: ', accuracy_score(y_test, y_pred_test))
if __name__ == '__main__':
    main()
    